package Modelagem;

public class Modelo {

	private String nome;


}
